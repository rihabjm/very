import { Component, OnInit } from '@angular/core';
import {FormControl,FormGroup,Validators} from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import {Formation} from '../../../Model/formation';
import {FormationService} from '../../../Service/formation.service';
import {Formateur} from '../../../Model/Formateur';
import {FormateurService} from '../../../Service/formateur.service';
import { NgbModalConfig, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import {Participant} from '../../../Model/Participant';
import {ParticipantService} from '../../../Service/participant.service';
import {Session} from '../../../Model/Session';
import {SessionService} from '../../../Service/session.service';
import {Inscrir} from '../../../Model/Inscrir';
import {InscrirService} from '../../../Service/inscrir.service';
@Component({
  selector: 'app-affichesession',
  templateUrl: './affichesession.component.html',
  styleUrls: ['./affichesession.component.scss']
})
export class AffichesessionComponent implements OnInit {



  open(content) {
    this.modalService.open(content);
  }
  openparticipant(contentparticipant) {
    this.modalService.open(contentparticipant);
  }


  constructor( private inscrirservice : InscrirService ,config: NgbModalConfig, private modalService: NgbModal ,private _Activatedroute:ActivatedRoute, private router: Router ,private formateurService: FormateurService, private formationserice: FormationService ,private participantservice :ParticipantService ,private sessionservice :SessionService)
     {
     config.backdrop = 'static';
    config.keyboard = false;
   }
   sub;
    id ;
 ids :number ;
    listeparticipant: Inscrir[] = new Array();
  inscrir :Inscrir=new Inscrir();
     formation : Formation =new Formation() ;
   formateur :Formateur =new Formateur() ;
formations: Formation[] = new Array();
inscrirs: Inscrir[] = new Array();
participant :Participant=new Participant();
listeSession : Session[] = new Array();
session : Session =new Session() ;
  ngOnInit() {
   this.sub=this._Activatedroute.paramMap.subscribe(params => {
         console.log(params);
                   this.id = params.get('id');
              this.formationserice.get(this.id)
      .subscribe(data => {
        console.log(data)
        this.formation = data;
      }, error => console.log(error));


               this.sessionservice.getSessionFormation(this.id)
      .subscribe(data => {
        console.log(data)
        this.listeSession = data;
      }, error => console.log(error));

      });

  }

delete(f){

for(let i=0;i< this.listeparticipant.length ;i++)
{if(this.listeparticipant[i]=f)
{
this.listeparticipant.splice(i) ;
}
}
}

  affectparticipant()
{

this.listeparticipant.push(this.inscrir);
this.inscrir=new Inscrir() ;


if(this.listeparticipant.length>=3 )
{this.test=false ;}
if(this.listeparticipant.length>=10)
{ this.test1=true ;
}
}

      getin()
      {
         this.sessionservice.getInscrir(this.id).subscribe(data => {
        console.log(data)
        this.listeparticipant = data;
      }, error => console.log(error));
      }

idse :number ;
test =true ;
test1=false  ;
savesession()
{
this.sessionservice.createProduct(this.session,this.formation.idformation).subscribe( data => {
for(let  i=0 ;i<=this.listeparticipant.length;i++)
{
this.sessionservice.addparticipant(this.listeparticipant[i],data.idsession).subscribe(data => {

      }, error => console.log(error));
}



}) ;



}





}





