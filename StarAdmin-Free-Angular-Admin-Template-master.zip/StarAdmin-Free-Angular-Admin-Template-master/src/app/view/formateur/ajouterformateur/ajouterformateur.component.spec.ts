import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AjouterformateurComponent } from './ajouterformateur.component';

describe('AjouterformateurComponent', () => {
  let component: AjouterformateurComponent;
  let fixture: ComponentFixture<AjouterformateurComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AjouterformateurComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AjouterformateurComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
