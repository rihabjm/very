import {Formation} from './formation';

export class Formationmodule extends Formation  {

nombreheure : number ;
}
