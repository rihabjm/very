import { ProgrammeKhademni } from './programme-khademni';

describe('ProgrammeKhademni', () => {
  it('should create an instance', () => {
    expect(new ProgrammeKhademni()).toBeTruthy();
  });
});
