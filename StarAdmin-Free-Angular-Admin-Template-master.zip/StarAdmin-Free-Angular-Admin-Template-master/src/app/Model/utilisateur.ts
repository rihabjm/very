export class Utilisateur {
  id: number;
  nom: string;
  prenom: string;
  telephone: string;
  adresse: string;
  dateNAisse :String ;
  sexe :String ;
  gmail :String ;
  login :String ;
  facebook :String ;
  linked :String ;
  mdp : String ;
}
