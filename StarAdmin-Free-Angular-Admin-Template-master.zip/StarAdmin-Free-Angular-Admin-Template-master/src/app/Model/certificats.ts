export class Certificats {
id_C : number;
intitule :String ;






}
